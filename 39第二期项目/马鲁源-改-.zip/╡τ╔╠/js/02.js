{
	"data": [{
		"id": "41d0d33761de45e1aafe35e6c316e435",
		"remarks": "",
		"createDate": "2019-05-26 19:18:26",
		"updateDate": "2019-05-31 13:48:26",
		"name": "配饰",
		"sort": "15",
		"cateID": "2054",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/peishi.jpg"
	}, {
		"id": "0aa48197beca4d3ab6cf08a6e1ae20a2",
		"remarks": "",
		"createDate": "2019-05-26 19:18:11",
		"updateDate": "2019-05-31 13:48:16",
		"name": "内衣",
		"sort": "14",
		"cateID": "989",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/neiyi.jpg"
	}, {
		"id": "7310b13214f54edea39b37d78c648d6b",
		"remarks": "",
		"createDate": "2019-05-26 19:18:03",
		"updateDate": "2019-05-31 13:47:55",
		"name": "电器",
		"sort": "13",
		"cateID": "97",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/dianqi.jpg"
	}, {
		"id": "f1e85e7d8e8b40348426c00d6879ad4d",
		"remarks": "",
		"createDate": "2019-05-26 19:17:54",
		"updateDate": "2019-05-31 13:47:35",
		"name": "数码",
		"sort": "12",
		"cateID": "97",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/shuma.jpg"
	}, {
		"id": "e5d115a95fdc4717a96f426c2b413d8b",
		"remarks": "",
		"createDate": "2019-05-26 19:17:46",
		"updateDate": "2019-05-31 13:47:18",
		"name": "美食",
		"sort": "11",
		"cateID": "2064",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/food.jpg"
	}, {
		"id": "579930658db94b74b3fa7924173ca741",
		"remarks": "",
		"createDate": "2019-05-26 19:17:32",
		"updateDate": "2019-05-31 13:47:06",
		"name": "文体",
		"sort": "10",
		"cateID": "2062",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/wt.jpg"
	}, {
		"id": "85785a1a52b24cd5b4cbd7261e9c95a0",
		"remarks": "",
		"createDate": "2019-05-26 19:17:16",
		"updateDate": "2019-05-31 13:46:45",
		"name": "家纺",
		"sort": "9",
		"cateID": "145",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/jiafang.jpg"
	}, {
		"id": "efc19bea0e774abb910ce37fe0614e92",
		"remarks": "",
		"createDate": "2019-05-26 19:16:54",
		"updateDate": "2019-05-31 13:46:35",
		"name": "居家",
		"sort": "8",
		"cateID": "125",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/jujia.jpg"
	}, {
		"id": "de52f5d2234448e8bbd310e9c2616859",
		"remarks": "",
		"createDate": "2019-05-26 19:11:59",
		"updateDate": "2019-05-31 13:46:14",
		"name": "美妆",
		"sort": "7",
		"cateID": "50522008",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/meizhuang.jpg"
	}, {
		"id": "f5901a77cc334f0b981b23680651ece6",
		"remarks": "",
		"createDate": "2019-05-26 19:11:46",
		"updateDate": "2019-05-31 13:46:03",
		"name": "母婴",
		"sort": "6",
		"cateID": "50006744",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/muying.jpg"
	}, {
		"id": "688178ae93a74854b20a5df1e0f2536d",
		"remarks": "",
		"createDate": "2019-05-26 19:11:35",
		"updateDate": "2019-05-31 13:45:47",
		"name": "箱包",
		"sort": "4",
		"cateID": "50015325",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/bao.png"
	}, {
		"id": "a303459e016d446ea4c9aab2a0f4b9fc",
		"remarks": "",
		"createDate": "2019-05-26 19:11:28",
		"updateDate": "2019-05-31 13:45:39",
		"name": "鞋子",
		"sort": "3",
		"cateID": "122398002",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/nvxie.jpg"
	}, {
		"id": "e2e30d2d197a4d55a8adc46eeeb3e86a",
		"remarks": "",
		"createDate": "2019-05-26 19:11:20",
		"updateDate": "2019-05-31 13:45:18",
		"name": "男装",
		"sort": "2",
		"cateID": "30",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/nanzhuang.jpg"
	}, {
		"id": "898396958acd436faca252c28b2d0cfc",
		"remarks": "",
		"createDate": "2019-05-26 19:11:12",
		"updateDate": "2019-05-31 13:43:41",
		"name": "女装",
		"sort": "1",
		"cateID": "16",
		"icon": "https://wumeili.top/userfiles/1/images/images/2019/05/nvzhuang.jpg"
	}],
	"message": "查询成功",
	"isShow": "1",
	"status": "0"
}