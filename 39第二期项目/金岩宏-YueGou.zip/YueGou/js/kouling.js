var string = window.location.search;
var url = getString(string, '?url=', '&text=', '?url=');
let uri = getString(string, '&text=', '&logo=', '&text=');
var text = decodeURI(uri);
var logo = getString(string, '&logo=', '', '&logo=');
function getString(string, startStr, endStr, alpha) {
	let start = string.indexOf(startStr);
	let end = string.indexOf(endStr);
	let str = string.slice(start, end).split(alpha);
	if (startStr.length == 0) {
		start = 0;
		str = string.slice(start).split(alpha);
	}
	if (endStr == 0) {
		end = string.length;
		str = string.slice(start).split(alpha);
	}
	return str[1];
}
// console.log(url, text, logo);
$.ajax({
	type: 'get',
	url: 'https://127.0.0.1/w/client/checkTBKkl',
	data: {
		url: url,
		text: text,
		logo: logo,
	},
	async: true,
	success: function (response) {
		let data = response.data.tbk_tpwd_create_response.data.model;
		let kouLing = document.getElementById('kouLing');
		kouLing.innerHTML =
			'复制这段消息' +
			'<p>' +
			data +
			'</p>' +
			'打开手机天猫，领取优惠券！';
	},
});
